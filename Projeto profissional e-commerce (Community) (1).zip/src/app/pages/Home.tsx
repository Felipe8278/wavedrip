import { motion } from 'motion/react';
import { ProductCard } from '../components/ProductCard';
import { products } from '../data/products';
import { Button } from '../components/ui/button';
import { ArrowRight, Sparkles, Zap, Shield, Truck, Store } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import type { Product } from '../context/AppContext';
import { ProductCarousel, ProductScrollBanner } from '../components/ProductCarousel';
import { VideoAd } from '../components/VideoAd';

export default function Home() {
  const navigate = useNavigate();
  const [allProducts, setAllProducts] = useState<Product[]>(products);
  const featuredProducts = allProducts.filter(p => p.featured).slice(0, 8);

  // Carregar produtos dos vendedores
  useEffect(() => {
    const usersData = localStorage.getItem('users');
    if (usersData) {
      const users = JSON.parse(usersData);
      const sellerProducts: Product[] = [];
      
      users.forEach((user: any) => {
        if (user.type === 'seller') {
          const productsKey = `seller_products_${user.id}`;
          const savedProducts = localStorage.getItem(productsKey);
          if (savedProducts) {
            const userProducts: Product[] = JSON.parse(savedProducts);
            sellerProducts.push(...userProducts);
          }
        }
      });

      setAllProducts([...products, ...sellerProducts]);
    }
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6bTAgMTZjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6TTIwIDM0YzAtMi4yMSAxLjc5LTQgNC00czQgMS43OSA0IDQtMS43OSA0LTQgNC00LTEuNzktNC00em0wIDE2YzAtMi4yMSAxLjc5LTQgNC00czQgMS43OSA0IDQtMS43OSA0LTQgNC00LTEuNzktNC00eiIvPjwvZz48L2c+PC9zdmc+')] opacity-20"></div>
        
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center text-white"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-6 py-2 mb-6"
            >
              <Sparkles className="h-4 w-4" />
              <span className="text-sm font-medium">Ofertas até 70% OFF</span>
            </motion.div>

            <motion.h1 
              className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              Tecnologia que
              <br />
              <span className="bg-gradient-to-r from-yellow-200 to-pink-200 bg-clip-text text-transparent">
                transforma vidas
              </span>
            </motion.h1>

            <motion.p 
              className="text-lg md:text-xl mb-8 text-white max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              Descubra os melhores produtos com qualidade premium e preços imbatíveis
            </motion.p>

            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              style={{ position: 'relative', zIndex: 20 }}
            >
              <Button
                size="lg"
                className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8 transition-transform hover:scale-105"
                onClick={() => navigate('/produtos')}
              >
                Ver Produtos
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white/10 text-lg px-8 transition-transform hover:scale-105 relative z-30 bg-transparent"
                style={{ position: 'relative', zIndex: 30 }}
              >
                <span className="relative z-30">Ofertas do Dia</span>
              </Button>
            </motion.div>
          </motion.div>
        </div>

        {/* Animated Background Elements */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute top-20 left-10 w-72 h-72 bg-white/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [90, 0, 90],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute bottom-20 right-10 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl"
        />
      </section>

      {/* Promotional Carousel - Shopee Style */}
      <ProductCarousel />

      {/* Product Scroll Banner - Shopee Style */}
      <ProductScrollBanner products={allProducts.slice(0, 12).map(p => ({
        id: p.id,
        name: p.name,
        price: p.price,
        image: p.image,
        discount: p.discount
      }))} />

      {/* Product Scroll Banner 2 - More Products */}
      <ProductScrollBanner products={allProducts.slice(8, 20).map(p => ({
        id: p.id,
        name: p.name,
        price: p.price,
        image: p.image,
        discount: p.discount
      }))} />

      {/* Promotional Banner */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              🎥 Promoções em Destaque
            </h2>
            <p className="text-gray-600">
              Confira nossas ofertas exclusivas em vídeo
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <VideoAd
                title="Smartphones em Promoção"
                description="Até 50% OFF em modelos selecionados"
                thumbnail="https://images.unsplash.com/photo-1654648662275-dfb19ec8d4a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHBob25lJTIwdGVjaG5vbG9neSUyMHByb21vdGlvbnxlbnwxfHx8fDE3NzUxNjgyNjd8MA&ixlib=rb-4.1.0&q=80&w=1080"
                videoUrl="#"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              viewport={{ once: true }}
            >
              <VideoAd
                title="Notebooks Super Oferta"
                description="Configurações potentes com preços imbatíveis"
                thumbnail="https://images.unsplash.com/photo-1641430034785-47f6f91ab6cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBjb21wdXRlciUyMG1vZGVybiUyMGRlc2t8ZW58MXx8fHwxNzc1MTY4MjY4fDA&ixlib=rb-4.1.0&q=80&w=1080"
                videoUrl="#"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              viewport={{ once: true }}
            >
              <VideoAd
                title="Fones Premium"
                description="Som de alta qualidade com cancelamento de ruído"
                thumbnail="https://images.unsplash.com/photo-1765279339828-bb765f3631c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aXJlbGVzcyUyMGhlYWRwaG9uZXMlMjBwcmVtaXVtfGVufDF8fHx8MTc3NTA5NTc2OXww&ixlib=rb-4.1.0&q=80&w=1080"
                videoUrl="#"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              viewport={{ once: true }}
            >
              <VideoAd
                title="Smartwatches"
                description="Monitore sua saúde com tecnologia avançada"
                thumbnail="https://images.unsplash.com/photo-1696688713460-de12ac76ebc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHdhdGNoJTIwZml0bmVzcyUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzc1MTY4MjY5fDA&ixlib=rb-4.1.0&q=80&w=1080"
                videoUrl="#"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Seller Banner */}
      <section className="py-12 bg-gradient-to-r from-purple-600 to-pink-600">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 md:p-12 text-center text-white border border-white/20"
          >
            <Store className="h-16 w-16 mx-auto mb-4" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Venda na TechShop
            </h2>
            <p className="text-lg mb-6 text-white/90 max-w-2xl mx-auto">
              Transforme sua paixão em negócio! Crie sua loja virtual e alcance milhares de clientes.
            </p>
            <Button
              size="lg"
              className="bg-white text-purple-600 hover:bg-gray-100"
              onClick={() => navigate('/register')}
            >
              Criar Conta de Vendedor
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { icon: Truck, title: 'Frete Grátis', description: 'Em compras acima de R$ 299' },
              { icon: Zap, title: 'Entrega Rápida', description: 'Receba em até 24h' },
              { icon: Shield, title: 'Compra Segura', description: 'Seus dados protegidos' },
              { icon: Sparkles, title: 'Garantia Estendida', description: 'Até 3 anos de garantia' },
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex items-center gap-4 p-4 bg-white rounded-lg"
              >
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-3 rounded-lg">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">{feature.title}</h3>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Produtos em Destaque
            </h2>
            <p className="text-gray-600">
              Os produtos mais vendidos e com melhor avaliação
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              size="lg"
              variant="outline"
              className="border-2"
              onClick={() => navigate('/produtos')}
            >
              Ver Todos os Produtos
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}