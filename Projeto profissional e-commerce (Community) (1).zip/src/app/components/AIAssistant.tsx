import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: 'Olá! 👋 Sou seu assistente virtual da TechShop. Como posso ajudar você hoje?',
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const getAIResponse = (userMessage: string): string => {
    const msg = userMessage.toLowerCase();
    
    // Perguntas sobre entrega
    if (msg.includes('entrega') || msg.includes('frete') || msg.includes('envio')) {
      return 'Oferecemos entrega expressa em até 24h para capitais! 🚚\n\nFrete GRÁTIS para compras acima de R$ 299.\n\nVocê pode calcular o frete na página do produto ou no carrinho.';
    }
    
    // Perguntas sobre pagamento
    if (msg.includes('pagamento') || msg.includes('pagar') || msg.includes('pix') || msg.includes('cartão')) {
      return 'Aceitamos diversas formas de pagamento: 💳\n\n• PIX (desconto de 5%)\n• Cartão de crédito (até 12x sem juros)\n• Cartão de débito\n• Boleto bancário\n\nTodas as transações são 100% seguras!';
    }
    
    // Perguntas sobre devolução
    if (msg.includes('devolv') || msg.includes('troca') || msg.includes('garantia')) {
      return 'Você tem 30 dias para devolução ou troca! 🔄\n\nTodos os produtos têm garantia mínima de 1 ano.\n\nPara solicitar, acesse "Meus Pedidos" e clique em "Solicitar Devolução".';
    }
    
    // Perguntas sobre rastreamento
    if (msg.includes('rastrear') || msg.includes('pedido') || msg.includes('onde está')) {
      return 'Para rastrear seu pedido: 📦\n\n1. Acesse "Meus Pedidos"\n2. Clique no pedido desejado\n3. Veja o status em tempo real\n\nVocê também recebe atualizações por e-mail!';
    }
    
    // Perguntas sobre produtos
    if (msg.includes('produto') || msg.includes('estoque') || msg.includes('disponível')) {
      return 'Temos mais de 100 produtos em diversas categorias! 🛍️\n\n• Eletrônicos\n• Moda\n• Casa e Decoração\n• Beleza\n• Livros\n• E muito mais!\n\nUse a barra de busca para encontrar o que precisa!';
    }
    
    // Perguntas sobre conta
    if (msg.includes('conta') || msg.includes('cadastro') || msg.includes('login')) {
      return 'Para criar sua conta: 👤\n\n1. Clique em "Entrar" no topo\n2. Selecione "Criar Conta"\n3. Preencha seus dados\n4. Pronto! Você já pode comprar!\n\nCom uma conta você pode rastrear pedidos e salvar favoritos.';
    }
    
    // Perguntas sobre vendedor
    if (msg.includes('vender') || msg.includes('vendedor') || msg.includes('loja')) {
      return 'Quer vender na TechShop? 🏪\n\n1. Crie uma conta de vendedor\n2. Configure sua loja\n3. Adicione produtos\n4. Comece a vender!\n\nSem taxas de adesão. Você só paga quando vender!';
    }
    
    // Resposta padrão
    return 'Entendi sua pergunta! 🤔\n\nPosso ajudar com:\n• Informações sobre entrega e frete\n• Formas de pagamento\n• Rastreamento de pedidos\n• Devoluções e garantia\n• Cadastro e login\n• Como vender na plataforma\n\nSobre o que você gostaria de saber?';
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI typing delay
    setTimeout(() => {
      const aiResponse: Message = {
        id: Date.now() + 1,
        text: getAIResponse(inputMessage),
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              onClick={() => setIsOpen(true)}
              size="lg"
              className="h-14 w-14 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg"
            >
              <MessageCircle className="h-6 w-6" />
            </Button>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute -top-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-white"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            transition={{ type: 'spring', damping: 25 }}
            className="fixed bottom-6 right-6 z-50 w-96 h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-white/20 backdrop-blur flex items-center justify-center">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-semibold">Assistente TechShop</h3>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="h-2 w-2 bg-green-400 rounded-full" />
                    <span>Online</span>
                  </div>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white/20"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            {/* Messages */}
            <ScrollArea ref={scrollRef} className="flex-1 p-4 bg-gray-50">
              <div className="space-y-4">
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                        message.sender === 'user'
                          ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                          : 'bg-white border shadow-sm'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-line">{message.text}</p>
                      <p className={`text-xs mt-1 ${message.sender === 'user' ? 'text-white/70' : 'text-gray-500'}`}>
                        {message.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </motion.div>
                ))}
                
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex justify-start"
                  >
                    <div className="bg-white border shadow-sm rounded-2xl px-4 py-3">
                      <div className="flex gap-1">
                        <motion.div
                          animate={{ y: [0, -5, 0] }}
                          transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
                          className="h-2 w-2 bg-gray-400 rounded-full"
                        />
                        <motion.div
                          animate={{ y: [0, -5, 0] }}
                          transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
                          className="h-2 w-2 bg-gray-400 rounded-full"
                        />
                        <motion.div
                          animate={{ y: [0, -5, 0] }}
                          transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                          className="h-2 w-2 bg-gray-400 rounded-full"
                        />
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            </ScrollArea>

            {/* Input */}
            <div className="p-4 border-t bg-white">
              <div className="flex gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Digite sua mensagem..."
                  className="flex-1"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim()}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Assistente disponível 24/7 para ajudar você! 🤖
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
