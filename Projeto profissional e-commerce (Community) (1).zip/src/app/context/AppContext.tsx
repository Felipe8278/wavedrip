import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  description: string;
  stock: number;
  featured?: boolean;
  sellerId: number;
  sellerName: string;
  sellerRating?: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: number;
  name: string;
  email: string;
  type: 'buyer' | 'seller';
  storeName?: string;
  storeDescription?: string;
  storeRating?: number;
  storeSales?: number;
}

export interface Order {
  id: string;
  userId: number;
  date: Date;
  items: Array<{
    id: number;
    name: string;
    image: string;
    price: number;
    quantity: number;
  }>;
  total: number;
  status: 'processing' | 'shipped' | 'delivered' | 'cancelled';
  trackingCode?: string;
  estimatedDelivery?: Date;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
  paymentMethod: string;
  shippingCost: number;
}

interface AppContextType {
  cart: CartItem[];
  user: User | null;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  register: (name: string, email: string, password: string, type: 'buyer' | 'seller', storeName?: string, storeDescription?: string) => boolean;
  getTotalItems: () => number;
  getTotalPrice: () => number;
  createOrder: (orderData: Omit<Order, 'id' | 'userId' | 'date' | 'status' | 'trackingCode' | 'estimatedDelivery'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const savedCart = localStorage.getItem('cart');
    return savedCart ? JSON.parse(savedCart) : [];
  });
  
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  const addToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const login = (email: string, password: string): boolean => {
    // Verificar se existe usuário salvo no localStorage
    const usersData = localStorage.getItem('users');
    if (usersData) {
      const users = JSON.parse(usersData);
      const foundUser = users.find((u: User) => u.email === email);
      if (foundUser) {
        setUser(foundUser);
        return true;
      }
    }

    // Simulação de login para usuários não cadastrados
    if (email && password.length >= 6) {
      const mockUser: User = {
        id: 1,
        name: email.split('@')[0],
        email,
        type: 'buyer'
      };
      setUser(mockUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const register = (name: string, email: string, password: string, type: 'buyer' | 'seller', storeName?: string, storeDescription?: string): boolean => {
    // Verificar se email já existe
    const usersData = localStorage.getItem('users');
    const users = usersData ? JSON.parse(usersData) : [];
    
    if (users.find((u: User) => u.email === email)) {
      return false; // Email já cadastrado
    }

    // Criar novo usuário
    const newUser: User = {
      id: Date.now(),
      name,
      email,
      type,
      storeName,
      storeDescription,
      storeRating: 5.0,
      storeSales: 0
    };

    // Salvar no localStorage
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    setUser(newUser);
    return true;
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const createOrder = (orderData: Omit<Order, 'id' | 'userId' | 'date' | 'status' | 'trackingCode' | 'estimatedDelivery'>) => {
    if (!user) {
      throw new Error('User must be logged in to create an order');
    }

    // Generate tracking code
    const trackingCode = `BR${Date.now().toString().slice(-10)}`;
    
    // Calculate estimated delivery (3-7 days from now)
    const estimatedDelivery = new Date();
    estimatedDelivery.setDate(estimatedDelivery.getDate() + Math.floor(Math.random() * 5) + 3);

    const newOrder: Order = {
      id: Date.now().toString(),
      userId: user.id,
      date: new Date(),
      items: cart.map(item => ({
        id: item.id,
        name: item.name,
        image: item.image,
        price: item.price,
        quantity: item.quantity
      })),
      total: getTotalPrice() + orderData.shippingCost,
      status: 'processing',
      trackingCode,
      estimatedDelivery,
      address: orderData.address,
      paymentMethod: orderData.paymentMethod,
      shippingCost: orderData.shippingCost
    };

    // Salvar o pedido específico do usuário
    const userOrdersKey = `user_orders_${user.id}`;
    const userOrdersData = localStorage.getItem(userOrdersKey);
    const userOrders = userOrdersData ? JSON.parse(userOrdersData) : [];
    userOrders.push(newOrder);
    localStorage.setItem(userOrdersKey, JSON.stringify(userOrders));

    // Limpar o carrinho
    clearCart();
  };

  return (
    <AppContext.Provider
      value={{
        cart,
        user,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        login,
        logout,
        register,
        getTotalItems,
        getTotalPrice,
        createOrder
      }}
    >
      {children}
    </AppContext.Provider>
  );
};