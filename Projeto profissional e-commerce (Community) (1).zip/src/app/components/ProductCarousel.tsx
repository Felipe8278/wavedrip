import { motion } from 'motion/react';
import { Tag, TrendingUp } from 'lucide-react';
import { useEffect, useRef } from 'react';

interface PromoItem {
  id: number;
  text: string;
  discount: string;
  color: string;
}

const promos: PromoItem[] = [
  { id: 1, text: 'Frete Grátis em toda loja', discount: '🚚 GRÁTIS', color: 'from-blue-500 to-cyan-500' },
  { id: 2, text: 'Smartphones até 50% OFF', discount: '50% OFF', color: 'from-purple-500 to-pink-500' },
  { id: 3, text: 'Notebooks com Super Desconto', discount: '40% OFF', color: 'from-orange-500 to-red-500' },
  { id: 4, text: 'Smartwatches em Promoção', discount: '35% OFF', color: 'from-green-500 to-teal-500' },
  { id: 5, text: 'Fones de Ouvido Premium', discount: '45% OFF', color: 'from-indigo-500 to-blue-500' },
  { id: 6, text: 'Câmeras com Cashback', discount: '💰 CASHBACK', color: 'from-yellow-500 to-orange-500' },
];

export function ProductCarousel() {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    let scrollAmount = 0;
    const scrollSpeed = 0.5;

    const scroll = () => {
      scrollAmount += scrollSpeed;
      if (scrollAmount >= scrollContainer.scrollWidth / 2) {
        scrollAmount = 0;
      }
      scrollContainer.scrollLeft = scrollAmount;
    };

    const intervalId = setInterval(scroll, 20);

    return () => clearInterval(intervalId);
  }, []);

  // Duplicar itens para criar efeito de loop infinito
  const duplicatedPromos = [...promos, ...promos, ...promos];

  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 py-3">
      <div 
        ref={scrollRef}
        className="flex gap-4 overflow-x-hidden scrollbar-hide"
        style={{ scrollBehavior: 'auto' }}
      >
        {duplicatedPromos.map((promo, index) => (
          <motion.div
            key={`${promo.id}-${index}`}
            className={`flex-shrink-0 bg-gradient-to-r ${promo.color} rounded-lg px-6 py-2 flex items-center gap-3 shadow-lg`}
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 400 }}
          >
            <Tag className="h-5 w-5 text-white" />
            <span className="text-white font-semibold whitespace-nowrap">
              {promo.text}
            </span>
            <span className="bg-white text-purple-600 px-3 py-1 rounded-full text-sm font-bold whitespace-nowrap">
              {promo.discount}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

interface ProductScrollBannerProps {
  products: Array<{
    id: number;
    name: string;
    price: number;
    image: string;
    discount?: number;
  }>;
}

export function ProductScrollBanner({ products }: ProductScrollBannerProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    let scrollAmount = 0;
    const scrollSpeed = 0.3;

    const scroll = () => {
      scrollAmount += scrollSpeed;
      if (scrollAmount >= scrollContainer.scrollWidth / 2) {
        scrollAmount = 0;
      }
      scrollContainer.scrollLeft = scrollAmount;
    };

    const intervalId = setInterval(scroll, 20);

    return () => clearInterval(intervalId);
  }, []);

  // Duplicar produtos para criar efeito de loop infinito
  const duplicatedProducts = [...products, ...products, ...products];

  return (
    <div className="relative overflow-hidden bg-white py-4 border-y-2 border-purple-200">
      <div 
        ref={scrollRef}
        className="flex gap-6 overflow-x-hidden scrollbar-hide"
        style={{ scrollBehavior: 'auto' }}
      >
        {duplicatedProducts.map((product, index) => (
          <motion.div
            key={`${product.id}-${index}`}
            className="flex-shrink-0 w-40 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-3 shadow-md border-2 border-purple-200 cursor-pointer"
            whileHover={{ scale: 1.05, y: -5 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="relative mb-2">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-32 object-cover rounded-lg"
              />
              {product.discount && (
                <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold shadow-lg">
                  -{product.discount}%
                </div>
              )}
            </div>
            <p className="text-sm font-semibold text-gray-800 mb-1 truncate">
              {product.name}
            </p>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-3 w-3 text-green-600" />
              <span className="text-purple-600 font-bold text-sm">
                R$ {product.price.toFixed(2)}
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
