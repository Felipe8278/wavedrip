import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Home } from 'lucide-react';

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-9xl font-bold text-gray-200 mb-4">404</h1>
        <h2 className="text-3xl font-bold mb-4">Página não encontrada</h2>
        <p className="text-gray-600 mb-8">
          A página que você está procurando não existe ou foi removida.
        </p>
        <Button
          size="lg"
          onClick={() => navigate('/')}
          className="bg-gradient-to-r from-blue-600 to-purple-600"
        >
          <Home className="mr-2 h-5 w-5" />
          Voltar para Início
        </Button>
      </div>
    </div>
  );
}
