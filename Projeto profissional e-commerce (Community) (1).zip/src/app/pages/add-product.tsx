import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { motion } from 'motion/react';
import { ArrowLeft, Save, Package } from 'lucide-react';
import type { Product } from '../context/AppContext';
import { categories } from '../data/products';

export default function AddProduct() {
  const { id } = useParams();
  const { user } = useApp();
  const navigate = useNavigate();
  const isEditing = !!id;

  const [formData, setFormData] = useState({
    name: '',
    price: '',
    originalPrice: '',
    image: '',
    category: 'Eletrônicos',
    description: '',
    stock: '',
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user || user.type !== 'seller') {
      navigate('/login');
      return;
    }

    if (isEditing) {
      const savedProducts = localStorage.getItem(`seller_products_${user.id}`);
      if (savedProducts) {
        const products: Product[] = JSON.parse(savedProducts);
        const product = products.find(p => p.id === Number(id));
        if (product) {
          setFormData({
            name: product.name,
            price: product.price.toString(),
            originalPrice: product.originalPrice?.toString() || '',
            image: product.image,
            category: product.category,
            description: product.description,
            stock: product.stock.toString(),
          });
        }
      }
    }
  }, [user, navigate, id, isEditing]);

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.name || !formData.price || !formData.image || !formData.description || !formData.stock) {
      setError('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    const price = parseFloat(formData.price);
    const originalPrice = formData.originalPrice ? parseFloat(formData.originalPrice) : undefined;
    const stock = parseInt(formData.stock);

    if (isNaN(price) || price <= 0) {
      setError('Preço inválido');
      return;
    }

    if (isNaN(stock) || stock < 0) {
      setError('Estoque inválido');
      return;
    }

    const savedProducts = localStorage.getItem(`seller_products_${user!.id}`);
    const products: Product[] = savedProducts ? JSON.parse(savedProducts) : [];

    if (isEditing) {
      // Editar produto existente
      const productIndex = products.findIndex(p => p.id === Number(id));
      if (productIndex !== -1) {
        products[productIndex] = {
          ...products[productIndex],
          name: formData.name,
          price,
          originalPrice,
          image: formData.image,
          category: formData.category,
          description: formData.description,
          stock,
        };
      }
    } else {
      // Criar novo produto
      const newProduct: Product = {
        id: Date.now(),
        name: formData.name,
        price,
        originalPrice,
        image: formData.image,
        category: formData.category,
        description: formData.description,
        stock,
        rating: 5.0,
        reviews: 0,
        sellerId: user!.id,
        sellerName: user!.storeName || user!.name,
        sellerRating: user!.storeRating || 5.0,
      };
      products.push(newProduct);
    }

    localStorage.setItem(`seller_products_${user!.id}`, JSON.stringify(products));
    navigate('/seller/dashboard');
  };

  if (!user || user.type !== 'seller') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl p-8"
        >
          <Button
            variant="ghost"
            onClick={() => navigate('/seller/dashboard')}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar ao Painel
          </Button>

          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">
                {isEditing ? 'Editar Produto' : 'Adicionar Novo Produto'}
              </h1>
              <p className="text-gray-600">Preencha as informações do produto</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Produto *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="Ex: Smartphone Premium"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Preço (R$) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => handleChange('price', e.target.value)}
                  placeholder="0.00"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="originalPrice">Preço Original (R$)</Label>
                <Input
                  id="originalPrice"
                  type="number"
                  step="0.01"
                  value={formData.originalPrice}
                  onChange={(e) => handleChange('originalPrice', e.target.value)}
                  placeholder="0.00 (opcional)"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Categoria *</Label>
                <select
                  id="category"
                  value={formData.category}
                  onChange={(e) => handleChange('category', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  {categories.filter(c => c !== 'Todos').map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="stock">Estoque *</Label>
                <Input
                  id="stock"
                  type="number"
                  value={formData.stock}
                  onChange={(e) => handleChange('stock', e.target.value)}
                  placeholder="0"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="image">URL da Imagem *</Label>
              <Input
                id="image"
                type="url"
                value={formData.image}
                onChange={(e) => handleChange('image', e.target.value)}
                placeholder="https://exemplo.com/imagem.jpg"
                required
              />
              {formData.image && (
                <div className="mt-2">
                  <img
                    src={formData.image}
                    alt="Preview"
                    className="w-32 h-32 object-cover rounded-lg border"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://via.placeholder.com/150?text=Imagem+Inválida';
                    }}
                  />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Descreva detalhadamente o produto..."
                rows={4}
                required
              />
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-600 text-sm"
              >
                {error}
              </motion.div>
            )}

            <div className="flex gap-3">
              <Button type="submit" className="flex-1" size="lg">
                <Save className="w-5 h-5 mr-2" />
                {isEditing ? 'Salvar Alterações' : 'Adicionar Produto'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/seller/dashboard')}
                size="lg"
              >
                Cancelar
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
