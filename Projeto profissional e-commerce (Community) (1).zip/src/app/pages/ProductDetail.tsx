import { useParams, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { products } from '../data/products';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ProductCard } from '../components/ProductCard';
import { ShoppingCart, Heart, Share2, Star, Truck, Shield, RotateCcw, Plus, Minus, Store } from 'lucide-react';
import { toast } from 'sonner';
import type { Product } from '../context/AppContext';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, cart } = useApp();
  const [quantity, setQuantity] = useState(1);
  const [product, setProduct] = useState<Product | null>(null);
  const [allProducts, setAllProducts] = useState<Product[]>(products);

  // Carregar produto (do catálogo padrão ou de vendedores)
  useEffect(() => {
    // Primeiro, procurar nos produtos padrão
    const defaultProduct = products.find(p => p.id === Number(id));
    if (defaultProduct) {
      setProduct(defaultProduct);
      return;
    }

    // Se não encontrar, procurar nos produtos de vendedores
    const usersData = localStorage.getItem('users');
    if (usersData) {
      const users = JSON.parse(usersData);
      const sellerProducts: Product[] = [];
      
      for (const user of users) {
        if (user.type === 'seller') {
          const productsKey = `seller_products_${user.id}`;
          const savedProducts = localStorage.getItem(productsKey);
          if (savedProducts) {
            const userProducts: Product[] = JSON.parse(savedProducts);
            sellerProducts.push(...userProducts);
            const foundProduct = userProducts.find(p => p.id === Number(id));
            if (foundProduct) {
              setProduct(foundProduct);
              break;
            }
          }
        }
      }

      setAllProducts([...products, ...sellerProducts]);
    }
  }, [id]);

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Produto não encontrado</h1>
        <Button onClick={() => navigate('/produtos')}>
          Voltar para Produtos
        </Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    toast.success(`${quantity} ${quantity === 1 ? 'item adicionado' : 'itens adicionados'} ao carrinho!`);
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/carrinho');
  };

  const recommendedProducts = allProducts
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Product Details */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-2xl overflow-hidden"
          >
            <div className="aspect-square relative">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              {discount > 0 && (
                <Badge className="absolute top-4 left-4 bg-red-500 text-lg px-4 py-2">
                  -{discount}% OFF
                </Badge>
              )}
            </div>
          </motion.div>

          {/* Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col"
          >
            <Badge className="w-fit mb-2">{product.category}</Badge>
            
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-6">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="font-semibold">{product.rating}</span>
              <span className="text-gray-500">
                ({product.reviews} avaliações)
              </span>
            </div>

            {/* Seller Info */}
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-4 mb-6 border border-purple-100">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white font-bold text-lg">
                  {product.sellerName.charAt(0)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Store className="h-4 w-4 text-purple-600" />
                    <p className="font-semibold">{product.sellerName}</p>
                  </div>
                  {product.sellerRating && (
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      <span>{product.sellerRating.toFixed(1)} vendedor</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Price */}
            <div className="bg-white rounded-xl p-6 mb-6">
              {product.originalPrice && (
                <p className="text-lg text-gray-400 line-through mb-1">
                  De: R$ {product.originalPrice.toFixed(2).replace('.', ',')}
                </p>
              )}
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-4xl font-bold text-gray-900">
                  R$ {product.price.toFixed(2).replace('.', ',')}
                </span>
                {discount > 0 && (
                  <span className="text-xl text-green-600 font-semibold">
                    {discount}% OFF
                  </span>
                )}
              </div>
              <p className="text-gray-600">
                ou 12x de R$ {(product.price / 12).toFixed(2).replace('.', ',')} sem juros
              </p>
            </div>

            {/* Quantity */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Quantidade</label>
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="text-xl font-semibold w-12 text-center">
                  {quantity}
                </span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                >
                  <Plus className="h-4 w-4" />
                </Button>
                <span className="text-sm text-gray-500">
                  {product.stock} disponíveis
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mb-6">
              <Button
                size="lg"
                className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg"
                onClick={handleBuyNow}
              >
                Comprar Agora
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="flex-1"
                onClick={handleAddToCart}
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                Adicionar ao Carrinho
              </Button>
            </div>

            <div className="flex gap-2 mb-6">
              <Button variant="outline" size="sm" className="flex-1">
                <Heart className="h-4 w-4 mr-2" />
                Favoritar
              </Button>
              <Button variant="outline" size="sm" className="flex-1">
                <Share2 className="h-4 w-4 mr-2" />
                Compartilhar
              </Button>
            </div>

            {/* Features */}
            <div className="space-y-3 bg-white rounded-xl p-6">
              <div className="flex items-center gap-3">
                <Truck className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Frete Grátis</p>
                  <p className="text-sm text-gray-600">Para todo o Brasil</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Garantia Estendida</p>
                  <p className="text-sm text-gray-600">3 anos de garantia</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <RotateCcw className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Devolução Grátis</p>
                  <p className="text-sm text-gray-600">Até 30 dias após a compra</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Description */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white rounded-2xl p-8 mb-16"
        >
          <h2 className="text-2xl font-bold mb-4">Descrição do Produto</h2>
          <p className="text-gray-600 leading-relaxed">
            {product.description}
          </p>
        </motion.div>

        {/* Recommended Products */}
        {recommendedProducts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-2xl font-bold mb-6">Produtos Relacionados</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {recommendedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}