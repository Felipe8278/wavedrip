import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { motion } from 'motion/react';
import { 
  Store, 
  Package, 
  DollarSign, 
  TrendingUp, 
  Plus,
  Edit,
  Trash2,
  Eye,
  BarChart3
} from 'lucide-react';
import type { Product } from '../context/AppContext';

export default function SellerDashboard() {
  const { user } = useApp();
  const navigate = useNavigate();
  const [myProducts, setMyProducts] = useState<Product[]>([]);

  useEffect(() => {
    // Verificar se é vendedor
    if (!user || user.type !== 'seller') {
      navigate('/login');
      return;
    }

    // Carregar produtos do vendedor do localStorage
    const savedProducts = localStorage.getItem(`seller_products_${user.id}`);
    if (savedProducts) {
      setMyProducts(JSON.parse(savedProducts));
    }
  }, [user, navigate]);

  if (!user || user.type !== 'seller') {
    return null;
  }

  const totalProducts = myProducts.length;
  const totalValue = myProducts.reduce((sum, p) => sum + (p.price * p.stock), 0);
  const totalStock = myProducts.reduce((sum, p) => sum + p.stock, 0);
  const avgRating = myProducts.length > 0 
    ? (myProducts.reduce((sum, p) => sum + p.rating, 0) / myProducts.length).toFixed(1)
    : '0.0';

  const handleDeleteProduct = (productId: number) => {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
      const updatedProducts = myProducts.filter(p => p.id !== productId);
      setMyProducts(updatedProducts);
      localStorage.setItem(`seller_products_${user.id}`, JSON.stringify(updatedProducts));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-2xl font-bold">
                {user.storeName?.charAt(0) || 'L'}
              </div>
              <div>
                <h1 className="text-2xl font-bold">{user.storeName || 'Minha Loja'}</h1>
                <p className="text-gray-600">{user.storeDescription || 'Vendedor TechShop'}</p>
              </div>
            </div>
            <Button onClick={() => navigate('/seller/add-product')} size="lg">
              <Plus className="w-5 h-5 mr-2" />
              Adicionar Produto
            </Button>
          </div>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-xl shadow-md p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Total de Produtos</p>
                <p className="text-3xl font-bold text-blue-600">{totalProducts}</p>
              </div>
              <Package className="w-12 h-12 text-blue-500 opacity-20" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-xl shadow-md p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Estoque Total</p>
                <p className="text-3xl font-bold text-purple-600">{totalStock}</p>
              </div>
              <BarChart3 className="w-12 h-12 text-purple-500 opacity-20" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-xl shadow-md p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Valor Total</p>
                <p className="text-3xl font-bold text-green-600">
                  R$ {totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <DollarSign className="w-12 h-12 text-green-500 opacity-20" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-xl shadow-md p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">Avaliação Média</p>
                <p className="text-3xl font-bold text-yellow-600">{avgRating} ⭐</p>
              </div>
              <TrendingUp className="w-12 h-12 text-yellow-500 opacity-20" />
            </div>
          </motion.div>
        </div>

        {/* Products List */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-2xl shadow-lg p-6"
        >
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Store className="w-6 h-6 text-purple-600" />
            Meus Produtos
          </h2>

          {myProducts.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">Você ainda não tem produtos cadastrados</p>
              <Button onClick={() => navigate('/seller/add-product')}>
                <Plus className="w-5 h-5 mr-2" />
                Adicionar Primeiro Produto
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3">Produto</th>
                    <th className="text-left p-3">Categoria</th>
                    <th className="text-right p-3">Preço</th>
                    <th className="text-right p-3">Estoque</th>
                    <th className="text-right p-3">Avaliação</th>
                    <th className="text-right p-3">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {myProducts.map((product, index) => (
                    <motion.tr
                      key={product.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="border-b hover:bg-gray-50 transition-colors"
                    >
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded-lg"
                          />
                          <div>
                            <div className="font-semibold">{product.name}</div>
                            <div className="text-sm text-gray-500">{product.reviews} avaliações</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-gray-600">{product.category}</td>
                      <td className="p-3 text-right font-semibold">
                        R$ {product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3 text-right">
                        <span className={`px-2 py-1 rounded-full text-sm ${
                          product.stock > 20 ? 'bg-green-100 text-green-700' :
                          product.stock > 10 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {product.stock}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <span className="flex items-center justify-end gap-1">
                          ⭐ {product.rating}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/products/${product.id}`)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/seller/edit-product/${product.id}`)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteProduct(product.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
