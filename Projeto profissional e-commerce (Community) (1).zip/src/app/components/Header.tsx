import { Link, useNavigate } from 'react-router';
import { ShoppingCart, Search, User, Menu, Heart, Package, MessageCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';
import { Badge } from './ui/badge';
import { useState, useEffect, useRef } from 'react';
import { products } from '../data/products';
import type { Product } from '../context/AppContext';
import { motion, AnimatePresence } from 'motion/react';

export function Header() {
  const { user, logout, getTotalItems } = useApp();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<Product[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const totalItems = getTotalItems();

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Auto-suggestions with typo correction
  useEffect(() => {
    if (searchQuery.trim().length > 1) {
      const query = searchQuery.toLowerCase().trim();
      
      // Load seller products
      const usersData = localStorage.getItem('users');
      let allProducts = [...products];
      if (usersData) {
        const users = JSON.parse(usersData);
        users.forEach((u: any) => {
          if (u.type === 'seller') {
            const productsKey = `seller_products_${u.id}`;
            const savedProducts = localStorage.getItem(productsKey);
            if (savedProducts) {
              allProducts = [...allProducts, ...JSON.parse(savedProducts)];
            }
          }
        });
      }

      // Fuzzy search with typo tolerance
      const filtered = allProducts.filter(product => {
        const name = product.name.toLowerCase();
        const category = product.category.toLowerCase();
        const description = product.description.toLowerCase();
        
        // Exact match or contains
        if (name.includes(query) || category.includes(query) || description.includes(query)) {
          return true;
        }
        
        // Fuzzy match for typos (simple Levenshtein distance)
        const words = query.split(' ');
        return words.some(word => {
          if (word.length < 3) return false;
          return name.includes(word) || category.includes(word);
        });
      }).slice(0, 6);

      setSuggestions(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/produtos?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (productId: number) => {
    navigate(`/produto/${productId}`);
    setSearchQuery('');
    setShowSuggestions(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80 shadow-sm">
      <div className="container mx-auto px-4">
        {/* Top Bar */}
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 flex-shrink-0">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-lg"
            >
              <Package className="h-6 w-6 text-white" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              TechShop
            </span>
          </Link>

          {/* Search Bar with Suggestions */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xl">
            <div ref={searchRef} className="relative w-full">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 z-10" />
              <Input
                type="search"
                placeholder="Busque por produtos, categorias..."
                className="pl-10 pr-4 w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => searchQuery.length > 1 && setSuggestions.length > 0 && setShowSuggestions(true)}
              />
              
              {/* Suggestions Dropdown */}
              <AnimatePresence>
                {showSuggestions && suggestions.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-full left-0 right-0 mt-2 bg-white border rounded-lg shadow-xl max-h-96 overflow-y-auto z-50"
                  >
                    <div className="p-2">
                      <p className="text-xs text-gray-500 px-3 py-2">Sugestões</p>
                      {suggestions.map((product) => (
                        <motion.button
                          key={product.id}
                          whileHover={{ backgroundColor: '#f3f4f6' }}
                          onClick={() => handleSuggestionClick(product.id)}
                          className="w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors"
                        >
                          <img 
                            src={product.image} 
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{product.name}</p>
                            <p className="text-xs text-gray-500">{product.category}</p>
                          </div>
                          <p className="font-bold text-blue-600">
                            R$ {product.price.toFixed(2)}
                          </p>
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </form>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {user ? (
              <div className="hidden md:flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={() => navigate('/pedidos')}>
                  <Package className="h-5 w-5 mr-1" />
                  Pedidos
                </Button>
                {user.type === 'seller' && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => navigate('/seller/dashboard')}
                    className="text-purple-600 hover:text-purple-700"
                  >
                    Minha Loja
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={logout}>
                  Olá, {user.name}
                </Button>
              </div>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/login')}
                className="hidden md:flex"
              >
                <User className="h-5 w-5 mr-2" />
                Entrar
              </Button>
            )}

            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/carrinho')}
              className="relative"
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-gradient-to-r from-blue-600 to-purple-600">
                  {totalItems}
                </Badge>
              )}
            </Button>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <nav className="flex flex-col gap-4 mt-8">
                  <Link to="/" className="text-lg">
                    Início
                  </Link>
                  <Link to="/produtos" className="text-lg">
                    Produtos
                  </Link>
                  {user ? (
                    <>
                      <Link to="/favoritos" className="text-lg">
                        Favoritos
                      </Link>
                      <Button variant="outline" onClick={logout}>
                        Sair
                      </Button>
                    </>
                  ) : (
                    <Link to="/login" className="text-lg">
                      Entrar
                    </Link>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Mobile Search */}
        <form onSubmit={handleSearch} className="pb-3 md:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              type="search"
              placeholder="Buscar produtos..."
              className="pl-10 pr-4"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </form>
      </div>

      {/* Navigation */}
      <div className="border-t">
        <div className="container mx-auto px-4">
          <nav className="flex items-center gap-6 h-12 overflow-x-auto">
            <Link to="/produtos?category=Computadores" className="text-sm whitespace-nowrap hover:text-blue-600 transition-colors">
              Computadores
            </Link>
            <Link to="/produtos?category=Smartphones" className="text-sm whitespace-nowrap hover:text-blue-600 transition-colors">
              Smartphones
            </Link>
            <Link to="/produtos?category=Áudio" className="text-sm whitespace-nowrap hover:text-blue-600 transition-colors">
              Áudio
            </Link>
            <Link to="/produtos?category=Gaming" className="text-sm whitespace-nowrap hover:text-blue-600 transition-colors">
              Gaming
            </Link>
            <Link to="/produtos?category=Periféricos" className="text-sm whitespace-nowrap hover:text-blue-600 transition-colors">
              Periféricos
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}