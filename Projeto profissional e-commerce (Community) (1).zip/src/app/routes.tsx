import { createBrowserRouter } from "react-router";
import Root from './Root';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Login from './pages/Login';
import Register from './pages/register';
import SellerDashboard from './pages/seller-dashboard';
import AddProduct from './pages/add-product';
import Orders from './pages/Orders';
import AdminPanel from './pages/AdminPanel';
import NotFound from './pages/NotFound';

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "produtos", Component: Products },
      { path: "produto/:id", Component: ProductDetail },
      { path: "carrinho", Component: Cart },
      { path: "checkout", Component: Checkout },
      { path: "login", Component: Login },
      { path: "register", Component: Register },
      { path: "pedidos", Component: Orders },
      { path: "admin", Component: AdminPanel },
      { path: "seller/dashboard", Component: SellerDashboard },
      { path: "seller/add-product", Component: AddProduct },
      { path: "seller/edit-product/:id", Component: AddProduct },
      { path: "*", Component: NotFound },
    ],
  },
]);