import { Link } from 'react-router';
import { Star, ShoppingCart, Store } from 'lucide-react';
import { Product } from '../context/AppContext';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useApp } from '../context/AppContext';
import { motion } from 'motion/react';
import { toast } from 'sonner';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useApp();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(product);
    toast.success('Produto adicionado ao carrinho!');
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ duration: 0.3 }}
    >
      <Link to={`/produto/${product.id}`}>
        <div className="group bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300">
          {/* Image */}
          <div className="relative aspect-square overflow-hidden bg-gray-100">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />
            {discount > 0 && (
              <Badge className="absolute top-3 left-3 bg-red-500">
                -{discount}%
              </Badge>
            )}
            {product.stock < 10 && (
              <Badge className="absolute top-3 right-3 bg-orange-500">
                Últimas unidades
              </Badge>
            )}
          </div>

          {/* Content */}
          <div className="p-4">
            <p className="text-xs text-gray-500 mb-1">{product.category}</p>
            <h3 className="font-semibold mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
              {product.name}
            </h3>

            {/* Seller Info */}
            <div className="flex items-center gap-1 mb-2 text-xs text-gray-600">
              <Store className="h-3 w-3" />
              <span className="line-clamp-1">{product.sellerName}</span>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-1 mb-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-3 w-3 ${
                      i < Math.floor(product.rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs text-gray-500">
                ({product.reviews})
              </span>
            </div>

            {/* Price */}
            <div className="mb-3">
              {product.originalPrice && (
                <p className="text-sm text-gray-400 line-through">
                  R$ {product.originalPrice.toFixed(2).replace('.', ',')}
                </p>
              )}
              <p className="text-2xl font-bold text-gray-900">
                R$ {product.price.toFixed(2).replace('.', ',')}
              </p>
              <p className="text-xs text-gray-500">
                ou 12x de R$ {(product.price / 12).toFixed(2).replace('.', ',')}
              </p>
            </div>

            {/* Add to Cart Button */}
            <Button
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Adicionar
            </Button>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}