import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { 
  Users, Package, ShoppingCart, TrendingUp, 
  Search, Filter, Download, BarChart3, 
  DollarSign, Eye, Trash2, Edit, ArrowLeft
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../components/ui/table';

interface AdminStats {
  totalUsers: number;
  totalOrders: number;
  totalRevenue: number;
  totalProducts: number;
}

export default function AdminPanel() {
  const { user } = useApp();
  const navigate = useNavigate();
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    totalOrders: 0,
    totalRevenue: 0,
    totalProducts: 0
  });
  const [users, setUsers] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    // Check if user is admin (for demo, we'll make user with specific email admin)
    if (!user || user.email !== 'admin@techshop.com') {
      navigate('/');
      return;
    }

    loadAdminData();
  }, [user, navigate]);

  const loadAdminData = () => {
    // Load all users
    const usersData = localStorage.getItem('users');
    const allUsers = usersData ? JSON.parse(usersData) : [];
    setUsers(allUsers);

    // Calculate total products
    let totalProducts = 100; // Base products
    allUsers.forEach((u: any) => {
      if (u.type === 'seller') {
        const productsKey = `seller_products_${u.id}`;
        const savedProducts = localStorage.getItem(productsKey);
        if (savedProducts) {
          totalProducts += JSON.parse(savedProducts).length;
        }
      }
    });

    // Calculate total orders and revenue
    let totalOrders = 0;
    let totalRevenue = 0;
    allUsers.forEach((u: any) => {
      const ordersKey = `user_orders_${u.id}`;
      const userOrders = localStorage.getItem(ordersKey);
      if (userOrders) {
        const orders = JSON.parse(userOrders);
        totalOrders += orders.length;
        totalRevenue += orders.reduce((sum: number, order: any) => sum + order.total, 0);
      }
    });

    setStats({
      totalUsers: allUsers.length,
      totalOrders,
      totalRevenue,
      totalProducts
    });
  };

  const deleteUser = (userId: number) => {
    if (confirm('Tem certeza que deseja excluir este usuário?')) {
      const updatedUsers = users.filter(u => u.id !== userId);
      localStorage.setItem('users', JSON.stringify(updatedUsers));
      setUsers(updatedUsers);
      loadAdminData();
    }
  };

  const filteredUsers = users.filter(u =>
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const StatCard = ({ icon: Icon, label, value, color, trend }: any) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
    >
      <Card className="p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-lg ${color}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          {trend && (
            <Badge className="bg-green-100 text-green-800">
              <TrendingUp className="h-3 w-3 mr-1" />
              {trend}
            </Badge>
          )}
        </div>
        <p className="text-sm text-gray-600 mb-1">{label}</p>
        <p className="text-2xl font-bold">{value}</p>
      </Card>
    </motion.div>
  );

  if (!user || user.email !== 'admin@techshop.com') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Painel Administrativo</h1>
              <p className="text-gray-600">Gerencie toda a plataforma TechShop</p>
            </div>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
              <Download className="h-4 w-4 mr-2" />
              Exportar Relatório
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            icon={Users}
            label="Total de Usuários"
            value={stats.totalUsers.toLocaleString()}
            color="bg-gradient-to-br from-blue-500 to-blue-600"
            trend="+12%"
          />
          <StatCard
            icon={ShoppingCart}
            label="Total de Pedidos"
            value={stats.totalOrders.toLocaleString()}
            color="bg-gradient-to-br from-purple-500 to-purple-600"
            trend="+8%"
          />
          <StatCard
            icon={DollarSign}
            label="Receita Total"
            value={`R$ ${stats.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
            color="bg-gradient-to-br from-green-500 to-green-600"
            trend="+23%"
          />
          <StatCard
            icon={Package}
            label="Total de Produtos"
            value={stats.totalProducts.toLocaleString()}
            color="bg-gradient-to-br from-pink-500 to-pink-600"
            trend="+5%"
          />
        </div>

        {/* Management Tabs */}
        <Card className="p-6">
          <Tabs defaultValue="users" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="users">
                <Users className="h-4 w-4 mr-2" />
                Usuários
              </TabsTrigger>
              <TabsTrigger value="products">
                <Package className="h-4 w-4 mr-2" />
                Produtos
              </TabsTrigger>
              <TabsTrigger value="orders">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Pedidos
              </TabsTrigger>
              <TabsTrigger value="analytics">
                <BarChart3 className="h-4 w-4 mr-2" />
                Análises
              </TabsTrigger>
            </TabsList>

            {/* Users Tab */}
            <TabsContent value="users">
              <div className="mb-4 flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Buscar usuários..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button variant="outline">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Loja</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Badge variant={user.type === 'seller' ? 'default' : 'secondary'}>
                            {user.type === 'seller' ? 'Vendedor' : 'Comprador'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {user.storeName || '-'}
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => deleteUser(user.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* Products Tab */}
            <TabsContent value="products">
              <div className="text-center py-12">
                <Package className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-xl font-semibold mb-2">Gerenciamento de Produtos</h3>
                <p className="text-gray-600 mb-6">
                  Total de {stats.totalProducts} produtos cadastrados na plataforma
                </p>
                <Button>Ver Todos os Produtos</Button>
              </div>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders">
              <div className="text-center py-12">
                <ShoppingCart className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-xl font-semibold mb-2">Gerenciamento de Pedidos</h3>
                <p className="text-gray-600 mb-6">
                  Total de {stats.totalOrders} pedidos processados
                </p>
                <Button>Ver Todos os Pedidos</Button>
              </div>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics">
              <div className="text-center py-12">
                <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-xl font-semibold mb-2">Análises e Relatórios</h3>
                <p className="text-gray-600 mb-6">
                  Visualize métricas detalhadas de desempenho da plataforma
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
                  <Button variant="outline">Vendas por Período</Button>
                  <Button variant="outline">Produtos Mais Vendidos</Button>
                  <Button variant="outline">Taxa de Conversão</Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </Card>

        {/* Quick Actions */}
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Ações Rápidas</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <Users className="h-8 w-8 text-blue-600 mb-3" />
              <h3 className="font-semibold mb-1">Adicionar Usuário</h3>
              <p className="text-sm text-gray-600">Criar nova conta de usuário</p>
            </Card>
            <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <Package className="h-8 w-8 text-purple-600 mb-3" />
              <h3 className="font-semibold mb-1">Adicionar Produto</h3>
              <p className="text-sm text-gray-600">Cadastrar novo produto</p>
            </Card>
            <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <Download className="h-8 w-8 text-green-600 mb-3" />
              <h3 className="font-semibold mb-1">Backup de Dados</h3>
              <p className="text-sm text-gray-600">Exportar todos os dados</p>
            </Card>
          </div>
        </div>

        {/* Info Box */}
        <Card className="p-6 mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <div className="flex items-start gap-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">Acesso Administrativo</h3>
              <p className="text-sm text-gray-600">
                Para acessar este painel, faça login com: <strong>admin@techshop.com</strong>
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
