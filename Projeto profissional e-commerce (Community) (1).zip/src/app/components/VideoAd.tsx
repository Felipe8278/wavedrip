import { motion } from 'motion/react';
import { Play } from 'lucide-react';

interface VideoAdProps {
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
}

export function VideoAd({ title, description, thumbnail, videoUrl }: VideoAdProps) {
  return (
    <motion.div
      className="relative group cursor-pointer overflow-hidden rounded-2xl shadow-2xl"
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <div className="relative h-64 md:h-80">
        <img
          src={thumbnail}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        
        {/* Play Button */}
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          initial={{ scale: 1 }}
          whileHover={{ scale: 1.1 }}
        >
          <div className="bg-white/90 backdrop-blur-sm rounded-full p-6 shadow-2xl">
            <Play className="h-12 w-12 text-purple-600 fill-purple-600" />
          </div>
        </motion.div>

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <h3 className="text-2xl font-bold mb-2">{title}</h3>
          <p className="text-white/90">{description}</p>
        </div>

        {/* Badge */}
        <div className="absolute top-4 right-4 bg-red-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
          🔥 AO VIVO
        </div>
      </div>
    </motion.div>
  );
}
