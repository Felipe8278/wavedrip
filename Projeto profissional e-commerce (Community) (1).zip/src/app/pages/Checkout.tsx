import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Separator } from '../components/ui/separator';
import { CreditCard, Barcode, Smartphone, MapPin, CheckCircle, Truck, Package } from 'lucide-react';
import { toast } from 'sonner';

export default function Checkout() {
  const { cart, getTotalPrice, user, createOrder } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [shippingMethod, setShippingMethod] = useState('standard');
  const [cepLoading, setCepLoading] = useState(false);

  const [formData, setFormData] = useState({
    fullName: user?.name || '',
    email: user?.email || '',
    phone: '',
    cep: '',
    address: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
  });

  const totalPrice = getTotalPrice();
  
  // Cálculo de frete dinâmico baseado no método escolhido
  const getShippingCost = () => {
    if (totalPrice > 299) return 0; // Frete grátis acima de R$ 299
    
    switch (shippingMethod) {
      case 'express':
        return 49.90; // Entrega expressa (1-2 dias)
      case 'fast':
        return 29.90; // Entrega rápida (3-5 dias)
      case 'standard':
      default:
        return 15.90; // Entrega padrão (7-10 dias)
    }
  };

  const shipping = getShippingCost();
  const finalTotal = totalPrice + shipping;

  if (cart.length === 0 && !orderPlaced) {
    navigate('/carrinho');
    return null;
  }

  // Simular busca de CEP (ViaCEP API simulation)
  const handleCepSearch = async () => {
    if (formData.cep.length !== 8 && formData.cep.length !== 9) {
      toast.error('CEP inválido');
      return;
    }

    setCepLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      // Mock data - em produção usar: https://viacep.com.br/ws/${cep}/json/
      setFormData({
        ...formData,
        address: 'Rua Exemplo',
        neighborhood: 'Centro',
        city: 'São Paulo',
        state: 'SP'
      });
      toast.success('CEP encontrado!');
      setCepLoading(false);
    }, 1000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    // Auto-format CEP
    if (name === 'cep') {
      const cleaned = value.replace(/\D/g, '');
      const formatted = cleaned.length > 5 ? 
        `${cleaned.slice(0, 5)}-${cleaned.slice(5, 8)}` : 
        cleaned;
      setFormData({ ...formData, [name]: formatted });
      
      // Auto-search when CEP is complete
      if (cleaned.length === 8) {
        handleCepSearch();
      }
      return;
    }
    
    // Auto-format phone
    if (name === 'phone') {
      const cleaned = value.replace(/\D/g, '');
      const formatted = cleaned.length > 10 ?
        `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7, 11)}` :
        cleaned.length > 6 ?
        `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 6)}-${cleaned.slice(6, 10)}` :
        cleaned.length > 2 ?
        `(${cleaned.slice(0, 2)}) ${cleaned.slice(2)}` :
        cleaned;
      setFormData({ ...formData, [name]: formatted });
      return;
    }
    
    setFormData({ ...formData, [name]: value });
  };

  const handlePlaceOrder = () => {
    // Validação básica
    if (!formData.fullName || !formData.email || !formData.cep || !formData.address || !formData.number) {
      toast.error('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    if (!user) {
      toast.error('Você precisa estar logado para finalizar a compra');
      navigate('/login');
      return;
    }

    try {
      // Create order using context
      createOrder({
        items: cart.map(item => ({
          id: item.id,
          name: item.name,
          image: item.image,
          price: item.price,
          quantity: item.quantity
        })),
        total: finalTotal,
        address: {
          street: `${formData.address}, ${formData.number}${formData.complement ? ' - ' + formData.complement : ''}`,
          city: formData.city,
          state: formData.state,
          zipCode: formData.cep
        },
        paymentMethod: paymentMethod === 'credit-card' ? 'Cartão de Crédito' : 
                       paymentMethod === 'pix' ? 'PIX' : 'Boleto Bancário',
        shippingCost: shipping
      });

      const newOrderId = `TS${Date.now().toString().slice(-8)}`;
      setOrderId(newOrderId);
      setOrderPlaced(true);
      toast.success('Pedido realizado com sucesso!');
    } catch (error) {
      toast.error('Erro ao processar pedido. Tente novamente.');
    }
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white rounded-2xl p-8 max-w-md text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
          >
            <CheckCircle className="h-12 w-12 text-green-600" />
          </motion.div>
          <h2 className="text-2xl font-bold mb-2">Pedido Realizado!</h2>
          <p className="text-gray-600 mb-6">
            Seu pedido foi confirmado e está sendo processado. Você receberá um e-mail de confirmação em breve.
          </p>
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-600 mb-1">Número do pedido</p>
            <p className="text-xl font-bold">{orderId}</p>
          </div>
          <Button
            size="lg"
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 mb-3"
            onClick={() => navigate('/')}
          >
            Voltar para Início
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="w-full"
            onClick={() => navigate('/produtos')}
          >
            Continuar Comprando
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Finalizar Compra</h1>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-4 max-w-2xl mx-auto">
            {[
              { num: 1, label: 'Entrega' },
              { num: 2, label: 'Pagamento' },
              { num: 3, label: 'Revisão' },
            ].map((s, index) => (
              <div key={s.num} className="flex items-center">
                <div className={`flex items-center gap-2 ${step >= s.num ? 'text-blue-600' : 'text-gray-400'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${
                    step >= s.num ? 'bg-blue-600 text-white' : 'bg-gray-200'
                  }`}>
                    {s.num}
                  </div>
                  <span className="hidden sm:inline">{s.label}</span>
                </div>
                {index < 2 && (
                  <div className={`w-12 sm:w-24 h-1 mx-2 ${step > s.num ? 'bg-blue-600' : 'bg-gray-200'}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg p-6"
            >
              {/* Step 1: Delivery */}
              {step === 1 && (
                <div>
                  <div className="flex items-center gap-2 mb-6">
                    <MapPin className="h-6 w-6 text-blue-600" />
                    <h2 className="text-2xl font-bold">Endereço de Entrega</h2>
                  </div>

                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="fullName">Nome Completo *</Label>
                        <Input
                          id="fullName"
                          name="fullName"
                          value={formData.fullName}
                          onChange={handleInputChange}
                          placeholder="Seu nome completo"
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">E-mail *</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="seu@email.com"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="phone">Telefone *</Label>
                        <Input
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="(00) 00000-0000"
                        />
                      </div>
                      <div>
                        <Label htmlFor="cep">CEP *</Label>
                        <div className="flex gap-2">
                          <Input
                            id="cep"
                            name="cep"
                            value={formData.cep}
                            onChange={handleInputChange}
                            placeholder="00000-000"
                            maxLength={9}
                          />
                          <Button 
                            type="button"
                            variant="outline"
                            onClick={handleCepSearch}
                            disabled={cepLoading}
                          >
                            {cepLoading ? 'Buscando...' : 'Buscar'}
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="address">Endereço *</Label>
                      <Input
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        placeholder="Rua, Avenida, etc"
                      />
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="number">Número *</Label>
                        <Input
                          id="number"
                          name="number"
                          value={formData.number}
                          onChange={handleInputChange}
                          placeholder="123"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="complement">Complemento</Label>
                        <Input
                          id="complement"
                          name="complement"
                          value={formData.complement}
                          onChange={handleInputChange}
                          placeholder="Apto, Bloco, etc"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="neighborhood">Bairro *</Label>
                        <Input
                          id="neighborhood"
                          name="neighborhood"
                          value={formData.neighborhood}
                          onChange={handleInputChange}
                          placeholder="Centro"
                        />
                      </div>
                      <div>
                        <Label htmlFor="city">Cidade *</Label>
                        <Input
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          placeholder="São Paulo"
                        />
                      </div>
                      <div>
                        <Label htmlFor="state">Estado *</Label>
                        <Input
                          id="state"
                          name="state"
                          value={formData.state}
                          onChange={handleInputChange}
                          placeholder="SP"
                          maxLength={2}
                        />
                      </div>
                    </div>

                    {/* Shipping Options */}
                    <div className="mt-6">
                      <Label className="mb-3 block">Método de Entrega</Label>
                      <RadioGroup value={shippingMethod} onValueChange={setShippingMethod}>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:border-blue-600">
                            <RadioGroupItem value="standard" id="standard" />
                            <Label htmlFor="standard" className="flex items-center justify-between cursor-pointer flex-1">
                              <div className="flex items-center gap-2">
                                <Package className="h-5 w-5" />
                                <div>
                                  <p className="font-medium">Entrega Padrão</p>
                                  <p className="text-sm text-gray-500">7-10 dias úteis</p>
                                </div>
                              </div>
                              <p className="font-bold">{totalPrice > 299 ? 'Grátis' : 'R$ 15,90'}</p>
                            </Label>
                          </div>

                          <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:border-blue-600">
                            <RadioGroupItem value="fast" id="fast" />
                            <Label htmlFor="fast" className="flex items-center justify-between cursor-pointer flex-1">
                              <div className="flex items-center gap-2">
                                <Truck className="h-5 w-5" />
                                <div>
                                  <p className="font-medium">Entrega Rápida</p>
                                  <p className="text-sm text-gray-500">3-5 dias úteis</p>
                                </div>
                              </div>
                              <p className="font-bold">{totalPrice > 299 ? 'Grátis' : 'R$ 29,90'}</p>
                            </Label>
                          </div>

                          <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:border-blue-600">
                            <RadioGroupItem value="express" id="express" />
                            <Label htmlFor="express" className="flex items-center justify-between cursor-pointer flex-1">
                              <div className="flex items-center gap-2">
                                <Truck className="h-5 w-5 text-blue-600" />
                                <div>
                                  <p className="font-medium">Entrega Expressa</p>
                                  <p className="text-sm text-gray-500">1-2 dias úteis</p>
                                </div>
                              </div>
                              <p className="font-bold">{totalPrice > 299 ? 'Grátis' : 'R$ 49,90'}</p>
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>
                      
                      {totalPrice > 299 && (
                        <div className="mt-4 bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-2">
                          <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                          <p className="text-sm text-green-800">
                            🎉 Você ganhou <strong>frete grátis</strong> neste pedido!
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <Button
                    size="lg"
                    className="w-full mt-6 bg-gradient-to-r from-blue-600 to-purple-600"
                    onClick={() => setStep(2)}
                  >
                    Continuar para Pagamento
                  </Button>
                </div>
              )}

              {/* Step 2: Payment */}
              {step === 2 && (
                <div>
                  <div className="flex items-center gap-2 mb-6">
                    <CreditCard className="h-6 w-6 text-blue-600" />
                    <h2 className="text-2xl font-bold">Forma de Pagamento</h2>
                  </div>

                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:border-blue-600 transition-colors">
                        <RadioGroupItem value="credit-card" id="credit-card" />
                        <Label htmlFor="credit-card" className="flex items-center gap-3 cursor-pointer flex-1">
                          <div className="bg-blue-100 p-2 rounded-lg">
                            <CreditCard className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium">Cartão de Crédito</p>
                            <p className="text-sm text-gray-500">Parcelamento em até 12x sem juros</p>
                          </div>
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:border-green-600 transition-colors">
                        <RadioGroupItem value="pix" id="pix" />
                        <Label htmlFor="pix" className="flex items-center gap-3 cursor-pointer flex-1">
                          <div className="bg-green-100 p-2 rounded-lg">
                            <Smartphone className="h-5 w-5 text-green-600" />
                          </div>
                          <div>
                            <p className="font-medium">PIX</p>
                            <p className="text-sm text-gray-500">Aprovação instantânea • 5% de desconto</p>
                          </div>
                          <div className="bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded">
                            5% OFF
                          </div>
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2 border rounded-lg p-4 cursor-pointer hover:border-yellow-600 transition-colors">
                        <RadioGroupItem value="boleto" id="boleto" />
                        <Label htmlFor="boleto" className="flex items-center gap-3 cursor-pointer flex-1">
                          <div className="bg-yellow-100 p-2 rounded-lg">
                            <Barcode className="h-5 w-5 text-yellow-600" />
                          </div>
                          <div>
                            <p className="font-medium">Boleto Bancário</p>
                            <p className="text-sm text-gray-500">Vencimento em 3 dias úteis</p>
                          </div>
                        </Label>
                      </div>
                    </div>
                  </RadioGroup>

                  {/* Payment Details */}
                  {paymentMethod === 'pix' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mt-4 bg-green-50 border border-green-200 rounded-lg p-4"
                    >
                      <p className="text-sm text-green-800">
                        ✅ Após confirmar o pedido, você receberá o código PIX para copiar e colar no app do seu banco.
                      </p>
                    </motion.div>
                  )}

                  <div className="flex gap-3 mt-6">
                    <Button
                      variant="outline"
                      size="lg"
                      className="flex-1"
                      onClick={() => setStep(1)}
                    >
                      Voltar
                    </Button>
                    <Button
                      size="lg"
                      className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600"
                      onClick={() => setStep(3)}
                    >
                      Continuar
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 3: Review */}
              {step === 3 && (
                <div>
                  <h2 className="text-2xl font-bold mb-6">Revisar Pedido</h2>

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Endereço de Entrega</h3>
                      <div className="bg-gray-50 rounded-lg p-4 text-sm">
                        <p>{formData.fullName}</p>
                        <p>{formData.address}, {formData.number}</p>
                        {formData.complement && <p>{formData.complement}</p>}
                        <p>{formData.neighborhood} - {formData.city}/{formData.state}</p>
                        <p>CEP: {formData.cep}</p>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Forma de Pagamento</h3>
                      <div className="bg-gray-50 rounded-lg p-4">
                        <p className="text-sm">
                          {paymentMethod === 'credit-card' && 'Cartão de Crédito'}
                          {paymentMethod === 'pix' && 'PIX'}
                          {paymentMethod === 'boleto' && 'Boleto Bancário'}
                        </p>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Itens do Pedido</h3>
                      <div className="space-y-2">
                        {cart.map(item => (
                          <div key={item.id} className="flex gap-3 bg-gray-50 rounded-lg p-3">
                            <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded" />
                            <div className="flex-1">
                              <p className="text-sm font-medium line-clamp-1">{item.name}</p>
                              <p className="text-sm text-gray-500">Qtd: {item.quantity}</p>
                            </div>
                            <p className="font-semibold">
                              R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 mt-6">
                    <Button
                      variant="outline"
                      size="lg"
                      className="flex-1"
                      onClick={() => setStep(2)}
                    >
                      Voltar
                    </Button>
                    <Button
                      size="lg"
                      className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600"
                      onClick={handlePlaceOrder}
                    >
                      Finalizar Pedido
                    </Button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-lg p-6 sticky top-24"
            >
              <h3 className="font-bold mb-4">Resumo do Pedido</h3>

              <div className="space-y-2 mb-4">
                {cart.map(item => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600 flex-1 truncate">
                      {item.quantity}x {item.name}
                    </span>
                    <span className="font-medium ml-2">
                      R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                ))}
              </div>

              <Separator className="my-4" />

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">
                    R$ {totalPrice.toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Frete</span>
                  <span className={`font-medium ${shipping === 0 ? 'text-green-600' : ''}`}>
                    {shipping === 0 ? 'Grátis' : `R$ ${shipping.toFixed(2).replace('.', ',')}`}
                  </span>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="flex justify-between items-center">
                <span className="text-lg font-bold">Total</span>
                <span className="text-2xl font-bold text-blue-600">
                  R$ {finalTotal.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}