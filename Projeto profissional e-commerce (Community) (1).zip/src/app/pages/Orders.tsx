import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Package, Truck, CheckCircle, Clock, ArrowLeft, MapPin } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

interface Order {
  id: string;
  date: Date;
  items: Array<{
    id: number;
    name: string;
    image: string;
    price: number;
    quantity: number;
  }>;
  total: number;
  status: 'processing' | 'shipped' | 'delivered' | 'cancelled';
  trackingCode?: string;
  estimatedDelivery?: Date;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
}

export default function Orders() {
  const { user } = useApp();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    // Load orders from localStorage
    const ordersKey = `user_orders_${user.id}`;
    const savedOrders = localStorage.getItem(ordersKey);
    if (savedOrders) {
      const parsedOrders = JSON.parse(savedOrders);
      // Convert date strings back to Date objects
      const ordersWithDates = parsedOrders.map((order: any) => ({
        ...order,
        date: new Date(order.date),
        estimatedDelivery: order.estimatedDelivery ? new Date(order.estimatedDelivery) : undefined
      }));
      setOrders(ordersWithDates);
    }
  }, [user, navigate]);

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'processing':
        return <Clock className="h-5 w-5" />;
      case 'shipped':
        return <Truck className="h-5 w-5" />;
      case 'delivered':
        return <CheckCircle className="h-5 w-5" />;
      default:
        return <Package className="h-5 w-5" />;
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'processing':
        return 'Processando';
      case 'shipped':
        return 'Em Transporte';
      case 'delivered':
        return 'Entregue';
      case 'cancelled':
        return 'Cancelado';
    }
  };

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'shipped':
        return 'bg-blue-100 text-blue-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
    }
  };

  const filterOrders = (status?: Order['status']) => {
    if (!status) return orders;
    return orders.filter(order => order.status === status);
  };

  const OrderCard = ({ order }: { order: Order }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="p-6 hover:shadow-lg transition-shadow">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="font-semibold text-lg">Pedido #{order.id}</h3>
            <p className="text-sm text-gray-500">
              {order.date.toLocaleDateString('pt-BR', { 
                day: '2-digit', 
                month: 'long', 
                year: 'numeric' 
              })}
            </p>
          </div>
          <Badge className={`${getStatusColor(order.status)} flex items-center gap-1`}>
            {getStatusIcon(order.status)}
            {getStatusText(order.status)}
          </Badge>
        </div>

        {/* Items */}
        <div className="space-y-3 mb-4">
          {order.items.map((item) => (
            <div key={item.id} className="flex items-center gap-4">
              <img
                src={item.image}
                alt={item.name}
                className="w-16 h-16 object-cover rounded-lg"
              />
              <div className="flex-1">
                <p className="font-medium text-sm">{item.name}</p>
                <p className="text-sm text-gray-500">Quantidade: {item.quantity}</p>
              </div>
              <p className="font-semibold">
                R$ {(item.price * item.quantity).toFixed(2)}
              </p>
            </div>
          ))}
        </div>

        {/* Tracking */}
        {order.trackingCode && (
          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="h-4 w-4 text-blue-600" />
              <p className="text-sm font-medium">Código de Rastreamento</p>
            </div>
            <p className="font-mono text-sm text-gray-700">{order.trackingCode}</p>
            {order.estimatedDelivery && (
              <p className="text-xs text-gray-500 mt-1">
                Previsão de entrega: {order.estimatedDelivery.toLocaleDateString('pt-BR')}
              </p>
            )}
          </div>
        )}

        {/* Address */}
        <div className="bg-gray-50 rounded-lg p-4 mb-4">
          <p className="text-sm font-medium mb-1">Endereço de Entrega</p>
          <p className="text-sm text-gray-600">
            {order.address.street}<br />
            {order.address.city}, {order.address.state}<br />
            CEP: {order.address.zipCode}
          </p>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t">
          <div>
            <p className="text-sm text-gray-500">Total</p>
            <p className="text-xl font-bold text-blue-600">
              R$ {order.total.toFixed(2)}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              Ver Detalhes
            </Button>
            {order.status === 'delivered' && (
              <Button size="sm" className="bg-gradient-to-r from-blue-600 to-purple-600">
                Avaliar
              </Button>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <h1 className="text-3xl font-bold mb-2">Meus Pedidos</h1>
          <p className="text-gray-600">
            Acompanhe todos os seus pedidos em um só lugar
          </p>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="all">
              Todos ({orders.length})
            </TabsTrigger>
            <TabsTrigger value="processing">
              Processando ({filterOrders('processing').length})
            </TabsTrigger>
            <TabsTrigger value="shipped">
              Em Transporte ({filterOrders('shipped').length})
            </TabsTrigger>
            <TabsTrigger value="delivered">
              Entregues ({filterOrders('delivered').length})
            </TabsTrigger>
            <TabsTrigger value="cancelled">
              Cancelados ({filterOrders('cancelled').length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {orders.length === 0 ? (
              <Card className="p-12 text-center">
                <Package className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-xl font-semibold mb-2">Nenhum pedido ainda</h3>
                <p className="text-gray-600 mb-6">
                  Quando você fizer uma compra, seus pedidos aparecerão aqui!
                </p>
                <Button onClick={() => navigate('/produtos')}>
                  Começar a Comprar
                </Button>
              </Card>
            ) : (
              orders.map(order => <OrderCard key={order.id} order={order} />)
            )}
          </TabsContent>

          <TabsContent value="processing" className="space-y-4">
            {filterOrders('processing').map(order => <OrderCard key={order.id} order={order} />)}
          </TabsContent>

          <TabsContent value="shipped" className="space-y-4">
            {filterOrders('shipped').map(order => <OrderCard key={order.id} order={order} />)}
          </TabsContent>

          <TabsContent value="delivered" className="space-y-4">
            {filterOrders('delivered').map(order => <OrderCard key={order.id} order={order} />)}
          </TabsContent>

          <TabsContent value="cancelled" className="space-y-4">
            {filterOrders('cancelled').map(order => <OrderCard key={order.id} order={order} />)}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
